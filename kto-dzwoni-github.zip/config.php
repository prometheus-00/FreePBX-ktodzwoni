<?php

return array(
    'db_host' => 'localhost',
    'db_name' => 'asterisk',
    'db_user' => 'freepbxuser',
    'db_pass' => 'CHANGE_ME',
);
